from flask import Flask, render_template, request, session, flash

from app.tictactoe import game, check_win, anticheat

app = Flask(__name__)
app.secret_key = 'BAD_SECRET_KEY'

FLAG = "fake{flag}"

@app.route('/')
def index():
    session['field'] = {"field": ['','','','','','','','','']}
    session['active'] = False
    return render_template("index.html")

@app.route('/reset')
def reset():
    session['field'] = {"field": ['','','','','','','','','']}
    session['active'] = True
    session['field'] = game(session['field']["field"])
    return session['field']


def check(session, request):
    if not session['active']:
        return False, "Игра не активна"
    
    if not anticheat(session['field']['field'], request):
        return False, "Кто-то решил схитрить...."

    return True, None


@app.route('/motion', methods=["POST"])
def motion():
    field = request.form.get("field").split(",")

    err, mess = check(session, field)
    if not err:
        session['field'] = {"field": ['','','','','','','','','']}
        session['active'] = False
        flash(mess, "danger")
        return render_template("index.html")

    ###
    # check win
    if check_win(field):                                             # <- from human win position
        session['active'] = False
        session['field']['message'] = FLAG
        return session['field']

    field = game(field)
    session['field'] = field

    ###
    # check win
    if check_win(field["field"]) or field["field"].count("") == 0:    # <- from comp win position
        session['active'] = False 
        session['field']['message'] = 'Попробуйте ещё-раз'
        return session['field']

    return field
