from math import inf as infinity
from random import choice

HUMAN = -1
COMP = +1

def evaluate(state):
    if wins(state, COMP):
        score = +1
    elif wins(state, HUMAN):
        score = -1
    else:
        score = 0

    return score

def check_win(field):
    state = translate_to(field)
    win_state = [
        [state[0][0], state[0][1], state[0][2]],
        [state[1][0], state[1][1], state[1][2]],
        [state[2][0], state[2][1], state[2][2]],
        [state[0][0], state[1][0], state[2][0]],
        [state[0][1], state[1][1], state[2][1]],
        [state[0][2], state[1][2], state[2][2]],
        [state[0][0], state[1][1], state[2][2]],
        [state[2][0], state[1][1], state[0][2]],
    ]
    for place1, place2, place3 in win_state:
        if place1 == place2 == place3 and place1 != 0:
            return True
    return False

def wins(state, player):
    win_state = [
        [state[0][0], state[0][1], state[0][2]],
        [state[1][0], state[1][1], state[1][2]],
        [state[2][0], state[2][1], state[2][2]],
        [state[0][0], state[1][0], state[2][0]],
        [state[0][1], state[1][1], state[2][1]],
        [state[0][2], state[1][2], state[2][2]],
        [state[0][0], state[1][1], state[2][2]],
        [state[2][0], state[1][1], state[0][2]],
    ]
    if [player, player, player] in win_state:
        return True
    else:
        return False


def game_over(state):
    return wins(state, HUMAN) or wins(state, COMP)


def empty_cells(state):
    cells = []

    for x, row in enumerate(state):
        for y, cell in enumerate(row):
            if cell == 0:
                cells.append([x, y])

    return cells


def valid_move(x, y):
    if [x, y] in empty_cells(board):
        return True
    else:
        return False


def minimax(state, depth, player):
    if player == COMP:
        best = [-1, -1, -infinity]
    else:
        best = [-1, -1, +infinity]

    if depth == 0 or game_over(state):
        score = evaluate(state)
        return [-1, -1, score]

    for cell in empty_cells(state):
        x, y = cell[0], cell[1]
        state[x][y] = player
        score = minimax(state, depth - 1, -player)
        state[x][y] = 0
        score[0], score[1] = x, y

        if player == COMP:
            if score[2] > best[2]:
                best = score  # max value
        else:
            if score[2] < best[2]:
                best = score  # min value

    return best


def ai_turn(c_choice, h_choice, board):
    depth = len(empty_cells(board))
    if depth == 0 or game_over(board):
        return


    if depth == 9:
        x = choice([0, 1, 2])
        y = choice([0, 1, 2])
    else:
        move = minimax(board, depth, COMP)
        x, y = move[0], move[1]


    board[x][y] = COMP
    return board


def translate_to(field):
    board = [[0 for i in range(3)] for j in range(3)]
    for i in range(3):
        for j in range(3):
            if field[i*3+j] == 'X': board[i][j] = COMP
            if field[i*3+j] == 'O': board[i][j] = HUMAN
    return board

def translate_from(board):
    field = []
    for row in board:
        for elem in row:
            if elem == 0: field.append('')
            if elem == COMP: field.append('X')
            if elem == HUMAN: field.append('O')
    return {"field":field}


def anticheat(past, present):
    past = translate_to(past)
    present = translate_to(present)

    changes = 0
    for i in range(3):
        for j in range(3):
            if past[i][j] ^ present[i][j] != 0:
                changes += 1
    if changes == 1: return True
    return False



def game(field):
    h_choice = 'O'  
    c_choice = 'X'  

    board = translate_to(field)
    board = ai_turn(c_choice, h_choice, board)  

    return translate_from(board)

