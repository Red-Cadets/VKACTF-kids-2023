let board = ['', '', '', '', '', '', '', '', ''];
const tiles = Array.from(document.querySelectorAll('.tile'));
let isGameActive = false;


function write(){
    tiles.forEach( (tile, index) => {
        if(board[index]=='X') {
            $(`#place${index+1}`).addClass('playerX');
            $(document).ready(
                function() {
                    $(`#place${index+1}`).text('X');
                });
        }
        if(board[index]=='O') {
            $(`#place${index+1}`).addClass('playerO');
            $(document).ready(
                function() {
                    $(`#place${index+1}`).text('O');
                })
        }
    });
}

window.addEventListener('DOMContentLoaded', () => {
    
    const playerDisplay = document.querySelector('.display-player');
    const resetButton = document.querySelector('#reset');
    const announcer = document.querySelector('.announcer');

    
    let Player = 'O';
    

    const isValidAction = (tile) => {
        if (tile.innerText === 'X' || tile.innerText === 'O'){
            return false;
        }

        return true;
    };



    const userAction = (tile, index) => {
        if(isValidAction(tile) && isGameActive) {
            board[index] = 'O'
            $(document).ready(function(){
                $.ajax({
                    url: '/motion',
                    type: 'post',
                    dataType: 'json',
                    contentType: 'application/x-www-form-urlencoded',
                    data: {field: String(board)},
                    success: function(response){
                        board = response.field;
                        write();
                        if(response["message"]){
                            $('#message').replaceWith(`<section class="controls" id="message">${response["message"]}</section>`);
                        }
                    }
                });
            });
        }
    }
    
    const resetBoard = () => {
        board = ['', '', '', '', '', '', '', '', ''];
        isGameActive = true;
        announcer.classList.add('hide');

        tiles.forEach(tile => {
            tile.innerText = '';
            tile.classList.remove('playerX');
            tile.classList.remove('playerO');
        });
    }

    tiles.forEach( (tile, index) => {
        tile.addEventListener('click', () => userAction(tile, index));
    });

    resetButton.addEventListener('click', resetBoard);

    
});

function start() {
    isGameActive = true;
    $('#message').replaceWith(`<section class="controls" id="message"></section>`);
    $(document).ready(function(){
        $.ajax({
            url: 'reset',
            type: 'get',
            dataType: 'JSON',
            success: function(response){
                board = response.field;
                write();
            }
        });
    });
  }